<?php

return [
    'map' => [
        "back" => "Revenir sur le site",
    ],
    'settings' => [
        "map-iframe" => "Iframe de la map",
        "info" => "Vous pouvez accéder à votre map en l'ajoutant dans la navbar ou en allant sur ",
    ]
];
