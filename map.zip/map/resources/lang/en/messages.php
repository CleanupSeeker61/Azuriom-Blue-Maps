<?php

return [
    'map' => [
        "back" => "Back to the site",
    ],
    'settings' => [
        "map-iframe" => "Map iframe",
        "info" => "You can access your map by adding it to the navbar or going to ",
    ]
];
